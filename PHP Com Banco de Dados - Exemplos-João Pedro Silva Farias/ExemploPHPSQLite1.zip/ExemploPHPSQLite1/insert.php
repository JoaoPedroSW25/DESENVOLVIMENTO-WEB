<?php
try{
    $pdo = new PDO('sqlite:database.db');

    $sql = "CREATE TABLE IF NOT EXISTS usuarios (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, idade INTEGER NOT NULL, email TEXT NOT NULL)";

    $pdo->exec($sql);

    if ($_SERVER['REQUEST_METHOD'] == "POST"){
        $nome = $_POST['nome'];
        $idade = $_POST['idade'];
        $email = $_POST['email'];

        $stmt = $pdo->prepare("INSERT INTO usuarios (nome, idade, email) VALUES (:nome, :idade, :email)");
        $stmt->bindParam(':nome', $nome);
        $stmt->bindParam(':idade', $idade);
        $stmt->bindParam(':email', $email);

        $stmt->execute();


        echo "Dados inseridos com sucesso!" ;
    }

}catch (PDOException $e){
    echo "Error: " . $e->getMessage();
}

?>
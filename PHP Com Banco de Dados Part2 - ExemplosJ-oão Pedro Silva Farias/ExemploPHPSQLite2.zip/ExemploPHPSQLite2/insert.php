<?php
try {
   $pdo = new PDO('sqlite:database.db');

   $sql = "CREATE TABLE IF NOT EXISTS usuarios (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT NOT NULL,
      email TEXT NOT NULL)";
   $pdo->exec($sql);

   if ($_SERVER['REQUEST_METHOD'] == 'POST'){

     $nome = $_POST['nome'];
     $email = $_POST['email'];

     $stmt = $pdo->prepare("INSERT INTO usuarios (nome, email) VALUES (:nome, :email)");
     $stmt->bindParam(':nome', $nome);
     $stmt->bindParam(':email', $email);
     $stmt->execute();


     echo "Usúario inserido com sucesso!";
     
   }
}catch (PDOException $e) {
   echo "Erro:" . $e->getMessage();
}
?>
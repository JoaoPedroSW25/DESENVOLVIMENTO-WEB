function calcIMC() {
    

var resultado = document.getElementById('resultado');
var altura = document.getElementById('altura').value / 100;
var peso = document.getElementById('peso').value;

    if (!altura || !peso || altura <= 0 || peso <= 0) {
        resultado.innerHTML = 'insira valores validos!';
        return;
    }
    
    const imc = peso / (altura ** 2);
    var classificação = '';


    if (imc < 18.5) {
        classificação = 'Baixo do Peso';
    } else if (imc < 24.9) {
        classificação = 'Peso Normal';
    } else if (imc < 29.9) {
        classificação = 'Acima do Peso';
    }else if (imc < 34.9) {
        classificação = 'Obessidade Grau I' ;
    }else if (imc < 39.9) {
        classificação = 'obessidade Grau II';
    }else {
        classificação = 'Obessidade Grau III';
    }

    resultado.innerHTML = `IMC: é <strong>${imc.toFixed(2)}</strong>-(${classificação})`;
    
}
var form = document.getElementById("myform");

form.addEventListener("submit", function(event) {
    event.preventDefault();
    
  const caixas = document.querySelectorAll(".box-input");

    caixas.forEach(box_input => {
        box_input.classList.remove('valido');
        box_input.classList.add('invalido');
        const error = box_input.querySelector('.error');
        if (error) error.innerHTML = "";
     });

    const nome = document.getElementById("nome");
    const input = nome.closest(".box-input");
    const nomevalor = nome.value;
   
    
    const errorspan = input.querySelector(".error");
     errorspan.innerHTML = "";

     input.classList.remove('invalido');
     input.classList.add('valido');

   if (!nomeÉvalido(nomevalor).Évalido) {
       errorspan.innerHTML = `${nomeÉvalido(nomevalor).mensagerror}`;
       input.classList.add('invalido');
       input.classList.remove('valido');
       
      
     return;


}
    const email = document.getElementById("email");
    const boxemail = email.closest(".box-input");
    const emailvalor = email.value.trim();

    const erroremail = boxemail.querySelector(".error");
     erroremail.innerHTML = "";


     boxemail.classList.remove('invalido');
     boxemail.classList.add('valido');
    
    if (!emailÉvalido(emailvalor).Évalido){
        erroremail.innerHTML = `${emailÉvalido(emailvalor).mensagerror}`;
        boxemail.classList.add('invaldo');
        boxemail.classList.remove('valido');
       
       
        return;
    }


    const mensagem = document.getElementById("mensagem");
    const boxmensagem = mensagem.closest(".box-input");
    const valormensagem = mensagem.value.trim();

    const errormensagem = boxmensagem.querySelector(".error");
     errormensagem.innerHTML = "";


     boxmensagem.classList.remove('invalido');
     boxmensagem.classList.add('valido');

    if (!mensagemÉvalido(valormensagem).Évalido){
        erroremail.innerHTML = `${mensagemÉvalido(valormensagem).mensagerror}`;
        boxmensagem.classList.add('invaldo');
        boxmensagem.classList.remove('valido');
       
        
    }else {
        boxmensagem.classList.remove('invalido');
        boxmensagem.classList.add('valido');
     
        return;

    }


    

});

function isEmpyt(value){
    return value.trim() === "";
}

function nomeÉvalido(value) {
    
    const validador = {
        Évalido : true,
        mensagerror : null
    };


    if (isEmpyt(value)){
        validador.Évalido = false;
        validador.mensagerror = "o campo é obrigatorio";
        return validador
    }

    if (value.length < 5){
       validador.Évalido = false;
        validador.mensagerror = " o campo deve ter no minimo 5 caracteres";
        return validador;
    }

    const regex = /^[a-zA-Z]/;

    if (!regex.test(value)) {
        validador.Évalido = false;
        validador.mensagerror = "o campo só pode conter letras";
        return validador;
    }
    
    return validador;

}

    function isEmpyt(value){
    return value.trim() === "";
}

    function emailÉvalido(value) {
      
      const validador = {
        Évalido : true,
      mensagerror : null  
    };


    if (isEmpyt(value)){
        validador.Évalido = false;
        validador.mensagerror = "o campo de email é obrigatorio";
        return validador;
    }
      
    const emailregex = /^[a-zA-Z0-9. %+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
     
    if (!emailregex.test(value)) {
         validador.Évalido = false;
        validador.mensagerror = " O Email deve ser valido!";
        return validador;
      }
       return validador;

}

function isEmpyt(value){
    return value.trim() === "";
}
function mensagemÉvalido(value) {
      
      const validador = {
        Évalido : true,
      mensagerror : null  
    };

   if (isEmpyt(value)){
        validador.Évalido = false;
        validador.mensagerror = "o campo de mensagem é obrigatorio";
    }
    else if (value.length < 25){
       validador.Évalido = false;
        validador.mensagerror = " o campo de mensagem deve ter no minimo 25 caracteres";
    }

     return validador;


     

}